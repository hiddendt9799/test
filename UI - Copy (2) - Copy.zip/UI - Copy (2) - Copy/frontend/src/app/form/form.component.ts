import { FormGroup, FormBuilder, Validators, FormGroupDirective } from "@angular/forms";
import { Component, OnInit,ElementRef,ViewChild,AfterViewInit,AfterViewChecked, Renderer2, HostListener } from "@angular/core";
import { ApiService } from "./api.service";
import { ExampleComponent } from "../example/example.component";
import { ChangeDetectorRef } from '@angular/core';
import { RouterTestingHarness } from "@angular/router/testing";
import { event } from "jquery";

@Component({
  selector: "app-form",
  templateUrl: "./form.component.html",
  styleUrls: ["./form.component.css"],
})
export class FormComponent implements OnInit, AfterViewChecked  {
  @ViewChild('chatContainer',{ static: false })  chatContainer: ElementRef | undefined;
  @ViewChild('analysisPanel',{ static: false })  analysisPanel!: ElementRef;

  
  sendQuestionDisabled:boolean = false;
  clearChatDisabled:boolean=false;
  private isResizing = false;
  private startX = 0;
  private startWidth = 0;
  isLoading:boolean = false;
  showUserUpload = true;
  loggedIn = true;
  isConfigPanelOpen = false;
  useGPT4V = false;
  useSuggestFollowupQuestions = true;
  selectedAnswer: number | null = null;
  activeAnalysisPanelTab: any;
  lastQuestion: string | null = null;
  currentQuestion: string | null = null;
  answer:any;
  answers: { question: string, answer: string, citations: string[]}[] = [];
  streamedAnswers: any[] = [];
  speechUrls: string[] = [];
  error: any = null;
  promptTemplate: string = '';
  temperature: number = 0.5;
  seed: string = '';
  minimumSearchScore: number = 0.5;
  minimumRerankerScore: number = 2.0;
  retrieveCount: number = 10;
  excludeCategory: string = '';
  useSemanticRanker: boolean = false;
  useSemanticCaptions: boolean = false;
  showSemanticRankerOption: boolean = true;
  lastQuestionRef:any=null;
  activeCitation:  string | undefined;
  citationHeight:string = '600px';
  activeTab:number = 0;
  showAnalysisPanel : boolean = false;
  selectedModel:string = 'GPT-4o';
  temporaryChatEnabled:boolean = false;
  dropdownOpen:boolean = false;
  supportingContent : { filename: string; content: string }[] = [];
  thoughtProcess: any[] = [];
  conversationId: string = this.generateConversationId();

  constructor(private chatservice: ApiService, private cdr: ChangeDetectorRef, private renderer: Renderer2, private elementRef: ElementRef){}
  ngOnInit(): void {
    this.initializeConversationId();
  }

  startResize(event: MouseEvent): void{
    this.isResizing = true;
    this.startX = event.clientX;
    this.startWidth = this.analysisPanel.nativeElement.offsetWidth;
    document.addEventListener('mousemove',this.resizePanel);
    document.addEventListener('mouseup',this.stopResize);
  }

  resizePanel = (event:MouseEvent): void => {
    if (this.isResizing && this.analysisPanel && this.analysisPanel.nativeElement){
      const deltaX = this.startX - event.clientX ;

      const newWidth = this.startWidth + deltaX;

      const minWidth = 200;
      const maxWidth = 900;
      const clampedWidth = Math.max(minWidth,Math.min(newWidth,maxWidth));

      this.renderer.setStyle(this.analysisPanel.nativeElement,'width',`${clampedWidth}px`);
    }
  };

  stopResize = (): void =>{
    this.isResizing = false;
    document.removeEventListener('mousemove',this.resizePanel);
    document.removeEventListener('mouseup',this.stopResize);
  };

  ngAfterViewChecked() {
    // this.scrollToBottom();
  }

  private scrollToBottom(): void {
    if (this.chatContainer && this.chatContainer.nativeElement) {
      console.log("chat container found:");
      const container = this.chatContainer.nativeElement;
        container.scrollTop = container.scrollHeight;
    }else{
      console.error("chat container not found or initialized");
    }
  }
  
  @HostListener('document:click',['$event'])
  handleClickOutside(event: Event):void {
    const clickedInside = this.elementRef.nativeElement.contains(event.target);
    if(!clickedInside ){
      this.dropdownOpen = false;
    }
  }
  
  @HostListener('document.keydown.escape',['$event'])
  handleEscKey(event:KeyboardEvent):void{
    this.dropdownOpen=false;
  }
 
  generateConversationId(): string {
    return Math.random().toString(36).substring(2,15);
  }

  private initializeConversationId():void{
    const storeId = sessionStorage.getItem('conversation_id');
    if(storeId){
      this.conversationId = storeId;
    }else {
      this.resetConversationId();
    }
  }

  private resetConversationId(): void{
    this.conversationId = this.generateConversationId();
    sessionStorage.setItem('conversation_id',this.conversationId);
  }

  chatHistory: { question: string; answer: string }[] = []; //store the conversion history
  onSend(data: { question: string, uploadedFileUrl: string | null }): void {
    if(this.sendQuestionDisabled) return;//avoid duplicate send during clearing
    console.log("send clicked for sure", data.question, "with file:", data.uploadedFileUrl || 'No file');  // Debugging log
    this.sendQuestionDisabled = true;//lock send during processing
    this.clearChatDisabled=true;//disable clear chat button
    this.isLoading = true;
    
    const requestData = {
      question: data.question,
      session_id: this.conversationId
    };

    this.currentQuestion = data.question;
    this.lastQuestion = data.question;
    this.isLoading = true;
    this.error = null;

    if (this.showAnalysisPanel) {  //panel close when new question is send.
      this.closeAnalysisPanel();
    }


    this.chatservice.sendQuestion(requestData).subscribe(
      (response: {answer:string,citations: string[]; supporting_content?:any[]; thought_process?:any[] }) => {
        console.log("API Response:",response)
        // if (response.answer && response.citations && response.citations.length !== undefined){
          this.chatHistory.push({question: data.question, answer:response.answer});
        this.answers.push({
          question: this.currentQuestion!,  
          answer: response.answer, 
          citations: response.citations || []
        });
        console.log("answer response is:",this.answer)
        
        this.thoughtProcess = response.thought_process || [];
        this.supportingContent = response.supporting_content || [];

        this.isLoading=false;
        this.sendQuestionDisabled = false;
        this.clearChatDisabled=false;

        this.currentQuestion = null;
        this.cdr.detectChanges();
        this.scrollToBottom();
      },
      error => {
        console.error('error occurred:', error);
        this.error = 'An error occurred. Please try again.';

        this.isLoading = false;
        this.sendQuestionDisabled = false;  
        this.clearChatDisabled=false;
      }
    );
    setTimeout(() => {
      if (this.isLoading) {
        this.isLoading = false;
        this.error = 'Request timed out. Please try again.';

        this.sendQuestionDisabled = false;
        this.clearChatDisabled = false;
      }
    }, 20000);
  }

  retryLastQuestion(): void {
    if (this.lastQuestion) {
      this.onSend({ question: this.lastQuestion, uploadedFileUrl: null });
    }
  }

  onReloadQuestion(question:string):void{
    this.onSend({ question, uploadedFileUrl: null });
  }
  
  onExampleClicked(example: string):void{
    this.onSend({question: example, uploadedFileUrl:null})
  }

  onTabSwitch(tabIndex:number): void{
    this.activeTab = tabIndex;
    this.showAnalysisPanel = true;
    this.cdr.detectChanges();

  }
 
  // Clear chat function with full reset of state
  clearChat(): void {
    if(this.clearChatDisabled) return; //prevent clearing if disable
    this.answers = [];
    this.streamedAnswers = [];
    this.lastQuestion = null;
    this.showAnalysisPanel = false;
    this.currentQuestion = null;
    this.activeTab = 0;
    this.activeCitation = undefined;
    this.isLoading=false;
    this.error=null;
    this.sendQuestionDisabled=false;
}

  onToggleTab(tab: any, index: number): void {
    this.activeAnalysisPanelTab = tab;
    this.selectedAnswer = index;
  } 

  onCitationClicked(citation: string) {
    // this.selectedCitation = citation;
    console.log('citation clicked is : ',citation)
    const parts = citation.split('_page_');
    const baseFileName = parts[0];
    const pageNumber = parts[1]?.replace('.pdf', '');
    
    this.activeCitation = `${baseFileName}.pdf#page=${pageNumber}`;;
    this.activeTab=2;
    this.showAnalysisPanel = true;
    console.log('PDF URL:', this.activeCitation);
  }

  ngOnDestroy():void{}

  closeAnalysisPanel(){
    this.showAnalysisPanel = false;
  }

  toggleDropdown():void{
    this.dropdownOpen = !this.dropdownOpen;
  }

  selectModel(model:string):void{
    this.selectedModel = model;
    this.dropdownOpen = false;
  }

  triggerFileUpload(): void {
    console.log('Upload file button clicked');
  }

  openSettingsPanel():void{
    this.isConfigPanelOpen=true;
    document.body.classList.add('sidePanelOpen');
  }
  closeSettingsPanel():void{
    this.isConfigPanelOpen=false;
    document.body.classList.remove('sidePanelOpen');
  }

  onPromptTemplateChange(value: string) {
    this.promptTemplate = value;
  }

  onTemperatureChange(value: number) {
    this.temperature = value;
  }

  onRetrieveCountChange(value: number) {
    this.retrieveCount = value;
  }

  onExcludeCategoryChanged(value: string) {
    this.excludeCategory = value;
  }

  onUseSemanticRankerChange(value: boolean) {
    this.useSemanticRanker = value;
  }

  onUseSemanticCaptionsChange(value: boolean) {
    this.useSemanticCaptions = value;
  }

  onFollowupQuestion(question: string):void {
    this.onSend({question, uploadedFileUrl:null})
  }

  onUseSuggestFollowupQuestionsChange(enabled: boolean) {
    this.useSuggestFollowupQuestions = enabled;
  }

  setIsConfigPanelOpen(state: boolean): void {
    this.isConfigPanelOpen = state;
  }

  toggleConfigPanel(): void {
    this.isConfigPanelOpen =!this.isConfigPanelOpen;
  }
  handleExampleClick(value: string): void{
    console.log('Example Clicked:',value);
  }
 
}
