import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { NxSwitcherModule } from "@aposin/ng-aquila/switcher";
import { NxExpertModule } from "@aposin/ng-aquila/config";
import { NxGridModule } from "@aposin/ng-aquila/grid";
import { NxLinkModule } from "@aposin/ng-aquila/link";
import { NxListModule } from "@aposin/ng-aquila/list";
import { NxIconModule } from "@aposin/ng-aquila/icon";
import { NxCardModule } from "@aposin/ng-aquila/card";
import { NxAccordionModule } from "@aposin/ng-aquila/accordion";
import { NxHeadlineModule } from "@aposin/ng-aquila/headline";
import { NxCopytextModule } from "@aposin/ng-aquila/copytext";
import { NxHeaderModule } from "@aposin/ng-aquila/header";
import { NxFooterModule } from "@aposin/ng-aquila/footer";
import { NxCheckboxModule } from "@aposin/ng-aquila/checkbox";
import { NxButtonModule } from "@aposin/ng-aquila/button";
import { NxTableModule } from "@aposin/ng-aquila/table";
import { NxMessageModule } from "@aposin/ng-aquila/message";
import { NxInputModule } from "@aposin/ng-aquila/input";
import { NxDropdownModule } from "@aposin/ng-aquila/dropdown";
import { NxPopoverModule } from "@aposin/ng-aquila/popover";
import { NxBadgeModule } from "@aposin/ng-aquila/badge";
import { NxSpinnerModule } from "@aposin/ng-aquila/spinner";
import { NxModalModule } from "@aposin/ng-aquila/modal";
import { NxDatefieldModule } from "@aposin/ng-aquila/datefield";
import { NxNativeDateModule } from "@aposin/ng-aquila/datefield";
import { NxMomentDateModule } from "@aposin/ng-aquila/moment-date-adapter";
import { NgChartsModule } from 'ng2-charts';
import { NxSidepanelModule } from '@aposin/ng-aquila/sidepanel';
import { NxTooltipModule } from '@aposin/ng-aquila/tooltip';
import { NxTabsModule } from '@aposin/ng-aquila/tabs';

// App components
import { HeaderComponent } from "./header/header.component";
import { FormComponent } from "./form/form.component";
import { ClearChatButtonComponent } from './clear-chat-button/clear-chat-button.component';
import { AnswerComponent } from './answer/answer.component';
import { AnalysisPanelComponent } from './analysis-panel/analysis-panel.component';
import { ExampleComponent } from './example/example.component';
import { QuestionInputComponent } from './question-input/question-input.component';
import { SettingsButtonComponent } from './settings-button/settings-button.component';
import { SupportingContentComponent } from './supporting-content/supporting-content.component';
import { UploadFileComponent } from './upload-file/upload-file.component';
import { UserChatMessageComponent } from './user-chat-message/user-chat-message.component';
import { AnswerErrorComponent } from './answer-error/answer-error.component';
import { AnswerLoadingComponent } from './answer-loading/answer-loading.component';
import { ThoughtProcessComponent } from './thought-process/thought-process.component';

//new 
import { MatToolbarModule } from "@angular/material/toolbar";  // For header toolbar
import { MatFormFieldModule } from '@angular/material/form-field';
// import { CommonModule } from '@angular/common';
// import { MatCardModule } from '@angular/material/card';
// import { MatTabsModule } from '@angular/material/tabs';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FormComponent,
    ClearChatButtonComponent,
    AnswerComponent,
    AnalysisPanelComponent,
    ExampleComponent,
    QuestionInputComponent,
    SettingsButtonComponent,
    SupportingContentComponent,
    UploadFileComponent,
    UserChatMessageComponent,
    AnswerErrorComponent,
    AnswerLoadingComponent,
    ThoughtProcessComponent,
  ],
  imports: [
    // MatTabsModule,
    // CommonModule,
    // MatCardModule,
    MatFormFieldModule,
    MatToolbarModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    NgChartsModule,
    AppRoutingModule,
    NxSwitcherModule,
    NxExpertModule,
    NxGridModule,
    NxLinkModule,
    NxListModule,
    NxIconModule,
    NxCardModule,
    NxAccordionModule,
    NxHeadlineModule,
    NxCopytextModule,
    NxHeaderModule,
    NxFooterModule,
    NxCheckboxModule,
    NxButtonModule,
    NxTableModule,
    NxMessageModule,
    NxBadgeModule,
    NxInputModule,
    NxDropdownModule,
    NxPopoverModule,
    NxSpinnerModule,
    NxModalModule,
    NxDatefieldModule,
    NxNativeDateModule,
    NxMomentDateModule,
    NxSidepanelModule,
    NxTooltipModule,
    NxTabsModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}