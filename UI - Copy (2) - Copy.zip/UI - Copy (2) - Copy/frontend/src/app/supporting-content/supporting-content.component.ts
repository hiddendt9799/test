import { Component } from '@angular/core';

@Component({
  selector: 'app-supporting-content',
  templateUrl: './supporting-content.component.html',
  styleUrls: ['./supporting-content.component.css']
})
export class SupportingContentComponent {

}
