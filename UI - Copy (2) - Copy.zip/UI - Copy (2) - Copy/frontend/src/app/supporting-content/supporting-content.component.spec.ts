import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupportingContentComponent } from './supporting-content.component';

describe('SupportingContentComponent', () => {
  let component: SupportingContentComponent;
  let fixture: ComponentFixture<SupportingContentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SupportingContentComponent]
    });
    fixture = TestBed.createComponent(SupportingContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
