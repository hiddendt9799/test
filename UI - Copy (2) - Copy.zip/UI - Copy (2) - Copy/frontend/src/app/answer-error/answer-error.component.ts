import { Component,Input,Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-answer-error',
  templateUrl: './answer-error.component.html',
  styleUrls: ['./answer-error.component.css']
})
export class AnswerErrorComponent {
  @Input() error: string='';
  @Output() retry = new EventEmitter<void>();

  onRetryClick(): void{
    this.retry.emit();
  }
}
