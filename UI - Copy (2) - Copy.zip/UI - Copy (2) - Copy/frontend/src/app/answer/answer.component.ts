import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import * as DOMPurify from 'dompurify';
import { ApiService } from '../form/api.service'; // Import ApiService

@Component({
  selector: 'app-answer',
  templateUrl: './answer.component.html',
  styleUrls: ['./answer.component.css']
})
export class AnswerComponent implements OnChanges {
  @Input() answer!: string;
  @Input() citations: string[]=[];
  @Input() isSelected: boolean = false;
  @Input() isStreaming: boolean = false;
  @Input() showFollowupQuestions: boolean = false;
  @Input() followupQuestions: string[] = [];
  @Output() citationClicked = new EventEmitter<string>();
  @Output() onFollowupQuestionClicked = new EventEmitter<string>();
  @Input() sanitizedAnswerHtml!: string;
  @Output() tabSwitch = new EventEmitter<number>();
  @Input() question: string;
  @Output() reloadQuestion = new EventEmitter<string>()
  
  inputText : string='';
  
  isCopied = false;
  isThumbsUp = false;
  isThumbsDown = false;
  isReloaded = false;

  constructor(private apiService: ApiService) {} // Inject ApiService
  // sanitizedAnswerHtml: string = '';

  ngOnChanges() {
    this.sanitizedAnswerHtml=DOMPurify.sanitize(this.answer);
  }

  onCitationClickedHandler(citation: string) {
    console.log('clicked_citation:',citation)
    this.citationClicked.emit(citation);
  }

  onFollowupQuestionClickedHandler(question: string) {
    this.onFollowupQuestionClicked.emit(question);
  }
  

  onThoughtProcessClicked() {
    this.tabSwitch.emit(0);
  }

  onSupportingContentClicked() {
    this.tabSwitch.emit(1);
  }

  onSubmit() {
    console.log('Submitted text:', this.inputText);
    
    // Call the feedback submit API
    this.apiService.submitFeedbackText(this.question, this.inputText).subscribe({
      next: (response) => {
        console.log('Feedback submitted successfully:', response);
        console.log('Feedback submitted successfully:',this.inputText)
        this.inputText = ''; // Clear input after submission
      },
      error: (error) => {
        console.error('Error submitting feedback:', error);
      }
    });
  }


  onCopyClick() {
    this.isCopied = !this.isCopied;
    // Copy the answer to clipboard logic
    const answerText = this.sanitizedAnswerHtml;
    navigator.clipboard.writeText(answerText).then(() => {
      console.log('Answer copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy!', err);
    });
  }

  onReloadClick() {
    this.isReloaded = !this.isReloaded;
    this.reloadQuestion.emit(this.question)
  }

  onThumbsUpClick() {
    this.isThumbsUp = !this.isThumbsUp;
    this.isThumbsDown = false; // Disable thumbs down when thumbs up is clicked

    // Call the API to submit thumbs up feedback
    this.apiService.submitFeedback(this.question, this.isThumbsUp ? 1 : 0, 0).subscribe({
      next: (response) => {
        console.log('Thumbs up submitted successfully:', response);
      },
      error: (error) => {
        console.error('Error submitting thumbs up:', error);
      }
    });
  }

  onThumbsDownClick() {
    this.isThumbsDown = !this.isThumbsDown;
    this.isThumbsUp = false; // Disable thumbs up when thumbs down is clicked

    // Call the API to submit thumbs down feedback
    this.apiService.submitFeedback(this.question, 0, this.isThumbsDown ? 1 : 0).subscribe({
      next: (response) => {
        console.log('Thumbs down submitted successfully:', response);
      },
      error: (error) => {
        console.error('Error submitting thumbs down:', error);
      }
    });
  }

}
