import { Component,EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-example',
  templateUrl: './example.component.html',
  styleUrls: ['./example.component.css']
})
export class ExampleComponent {
  examples:string[]=[
    "Question Example 1",
    "Question Example 2",
    "Question Example 3"
  ];
@Output() onExampleClicked = new EventEmitter<string>();

handleClick(value: string): void{
  this.onExampleClicked.emit(value);
}
}
