import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClearChatButtonComponent } from './clear-chat-button.component';

describe('ClearChatButtonComponent', () => {
  let component: ClearChatButtonComponent;
  let fixture: ComponentFixture<ClearChatButtonComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ClearChatButtonComponent]
    });
    fixture = TestBed.createComponent(ClearChatButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
