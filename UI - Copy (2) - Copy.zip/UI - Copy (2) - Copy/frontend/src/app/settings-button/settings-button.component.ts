import { Component,Input,Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-settings-button',
  templateUrl: './settings-button.component.html',
  styleUrls: ['./settings-button.component.css']
})
export class SettingsButtonComponent {
  @Input() className: string = '';
  @Output() onClick = new EventEmitter<void>();

  handleClick(){
    this.onClick.emit();
  }
}
