import { Component, Input } from '@angular/core';
 
interface ThoughtStep{
  title: string;
  description: any
  prop?: {[key: string]: any}
}
 
@Component({
  selector: 'app-thought-process',
  templateUrl: './thought-process.component.html',
  styleUrls: ['./thought-process.component.css']
})
export class ThoughtProcessComponent {
  @Input() thoughts: ThoughtStep[] = [];
 
  isArray(value: any): boolean {
    return Array.isArray(value);
  }
 
  // objectKeys(obj: any): string[] {
  //   return Object.keys(obj);
  // }
 
  // isObject(value: any):boolean{
  //   return value && typeof value === 'object' && !Array.isArray(value);
  // }
 
  stringify(value: any): string {
    return JSON.stringify(value,null,2);
  }
 
  isObject(value: any): boolean {
    return value && typeof value === 'object';
  }
 
  formatObject(obj: any, indent: number = 2): string {
    if (Array.isArray(obj)) {
      return obj.map(item => this.formatObject(item, indent + 2)).join('\n');
    } else if (typeof obj === 'object' && obj !== null) {
      let formatted = '';
      for (const [key, value] of Object.entries(obj)) {
        const padding = ' '.repeat(indent);
        formatted += `${padding}${key}: ${this.formatObject(value, indent + 2)}\n`;
      }
      return formatted.trim();
    } else {
      return String(obj);
    }
  }
 
  objectKeys(obj: any): string[] {
    return Object.keys(obj);
  }
}