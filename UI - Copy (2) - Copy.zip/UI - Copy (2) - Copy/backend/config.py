import os
from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

# Attempt to load the .env file, and handle the case when it's missing.
env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    load_dotenv(dotenv_path=env_path)
else:
    print(f".env file not found at {env_path}. Using default environment variables.")

# Global app constants
BASE_DIR = Path(__file__).parent.parent
APP_DIR = Path(__file__).parent
API_PREFIX_V1 = "/api"

class AppConfig(BaseSettings):
    BASE_DIR: Path = BASE_DIR
    APP_DIR: Path = APP_DIR
    DEFAULT_API_KEY: str = os.getenv("DEFAULT_API_KEY", "default_api_key")  # Provide a default value
    AZURE_OPENAI_CONFIG: dict = {
        "model_name": os.getenv("AZURE_OPENAI_MODEL_NAME", "default_model_name"),  # Provide a default
        "azure_deployment": os.getenv("AZURE_OPENAI_DEPLOYMENT", "default_deployment"),
        "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "default_version"),
        "azure_endpoint": os.getenv("AZURE_OPENAI_ENDPOINT", "default_endpoint"),
        "temperature": float(os.getenv("OPENAI_MODEL_TEMPERATURE", 0.25)),  # Default temp if not provided
        "api_key": os.getenv("AZURE_OPENAI_API_KEY", "default_api_key")  # Default API key
    }
    AZURE_OPENAI_EMBEDDING_CONFIG: dict = {
        "azure_deployment": os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "default_embedding_deployment"),
        "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "default_version"),
    }
    POSTGRES_DB_CONFIG: dict = {
        "pg_host": os.getenv("POSTGRES_HOST", "localhost"),  # Default to localhost if not set
        "pg_user": os.getenv("POSTGRES_USER", "user"),
        "pg_port": os.getenv("POSTGRES_PORT", "5432"),  # Default port
        "pg_database": os.getenv("POSTGRES_DB", "db_name"),
        "collection_name": os.getenv("PGVECTOR_COLLECTION", "default_collection")
    }
    FAISS_DB_CONFIG: dict = {
        "url": os.getenv("FAISS_DB_ENDPOINT", "http://localhost:5000")  # Default endpoint
    }
    AZURE_TENANT_ID: str = os.getenv("AZURE_TENANT_ID", "default_tenant_id")
    AZURE_CLIENT_ID: str = os.getenv("AZURE_CLIENT_ID", "default_client_id")
    AZURE_CLIENT_SECRET: str = os.getenv("AZURE_CLIENT_SECRET", "default_client_secret")

# Instantiate the config object
settings = AppConfig()
# """
# All configurations to be used in FastAPI app can be created here.
# """
# import os
# from functools import lru_cache

# from pathlib import Path
# from pydantic_settings import BaseSettings
# from dotenv import load_dotenv

# load_dotenv("./.env")

# # Global app constants
# BASE_DIR = Path(__file__).parent.parent
# APP_DIR = Path(__file__).parent
# API_PREFIX_V1 = "/api"

# class AppConfig(BaseSettings):
#     BASE_DIR: Path = BASE_DIR
#     APP_DIR: Path = APP_DIR
#     DEFAULT_API_KEY:str = os.environ.get("DEFAULT_API_KEY")
#     AZURE_OPENAI_CONFIG:dict = {
#             "model_name": os.environ.get("AZURE_OPENAI_MODEL_NAME"),
#             "azure_deployment":os.environ.get("AZURE_OPENAI_DEPLOYMENT"),
#             "api_version":os.environ.get("AZURE_OPENAI_API_VERSION"),
#             "azure_endpoint":os.environ.get("AZURE_OPENAI_ENDPOINT"),
#             "temperature":float(os.environ.get("OPENAI_MODEL_TEMPERATURE",0.25)),
#             "api_key":os.environ.get("AZURE_OPENAI_API_KEY")
#     }
#     AZURE_OPENAI_EMBEDDING_CONFIG:dict = {
#         "azure_deployment":os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT"),
#         "api_version":os.environ.get("AZURE_OPENAI_API_VERSION"),
#     }
#     POSTGRES_DB_CONFIG:dict = {
#         "pg_host":os.environ.get("POSTGRES_HOST"),
#         "pg_user":os.environ.get("POSTGRES_USER"),
#         "pg_port":os.environ.get("POSTGRES_PORT"),
#         "pg_database":os.environ.get("POSTGRES_DB"),
#         "collection_name":os.environ.get("PGVECTOR_COLLECTION")
#     }
#     FAISS_DB_CONFIG:dict = {
#         "url":os.environ.get("FAISS_DB_ENDPOINT")
#     }

#     AZURE_TENANT_ID:str = os.environ.get("AZURE_TENANT_ID")
#     AZURE_CLIENT_ID:str = os.environ.get("AZURE_CLIENT_ID")
#     AZURE_CLIENT_SECRET:str = os.environ.get("AZURE_CLIENT_SECRET")

# settings = AppConfig()
