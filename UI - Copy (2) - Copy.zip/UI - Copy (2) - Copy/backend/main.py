from fastapi import FastAPI, status, Depends
from fastapi.security import HTTPBearer
from starlette.middleware.cors import CORSMiddleware
from src.middlewares.auth import AuthMiddleware
from src.middlewares.cors import HandleOptionsMiddleware
from src.views import router
from src.exception_handler import ExceptionHandler
from config import API_PREFIX_V1

bearer = HTTPBearer()


def get_application() -> FastAPI:
    """ Configure, start and return the application """
    # Start FastApi App
    application = FastAPI(
        title="Aviva_RAG",
        description="RAG proposal",
        version="1.0.0",
        openapi_url="/api/docs/openapi.json",
        docs_url="/api/docs/swagger",
        redoc_url="/api/docs/redoc",
        )

    application.max_request_size = 10 * 1024 * 1024  # 10MB

    # Mapping api routes
    application.include_router(router, prefix=API_PREFIX_V1)#Comment this
    # Uncomment below
    # application.include_router(router, prefix=API_PREFIX_V1, dependencies=[Depends(bearer)])

    # Add custom middlewares here
    application.add_middleware(HandleOptionsMiddleware)

    # Add custom exception handlers
    application.add_exception_handler(handler=ExceptionHandler.handler,
                                      exc_class_or_status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    # Uncomment below
    # application.add_middleware(
    #     AuthMiddleware
    # )
    # Allow cors
    application.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    return application


app = get_application()

@app.get("/")
async def readiness():
    """This is used by the K8s readiness probe."""
    return {"message": "API is available", "path": "/", "build_id": 1}