from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse
from config import settings

api_key = settings.DEFAULT_API_KEY


class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint):
        # Code to execute before the route handler is called
        if '/docs' in str(request.url) or '/openapi.json' in str(request.url):
            response = await call_next(request)
            return response
        token = request.headers.get('Authorization')
        if token is None:
            return JSONResponse(status_code=403, content={"message": "No token found"})
        token = self.get_the_token_from_header(token)
        if not self.verify_token(token):
            return JSONResponse(status_code=401, content={"message": "Invalid token"})
        request.scope.update(headers=request.headers.raw)
        response = await call_next(request)
        return response

    @classmethod
    def get_the_token_from_header(cls, token):
        """
        Clean the token string from header
        :param token:
        :return:
        """
        token = token.replace('Bearer', '').replace(' ', '')
        # clean the token
        return token
    
    @classmethod
    def verify_token(cls, token):
        """
        Logic to verify user token

        Args:
            token:str
        Return
            bool
        """
        return token==api_key