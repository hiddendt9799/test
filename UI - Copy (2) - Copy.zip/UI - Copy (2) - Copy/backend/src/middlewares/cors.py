from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse


class HandleOptionsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.method == "OPTIONS":
            # Handle OPTIONS request to add CORS headers
            response = JSONResponse(content={}, status_code=200)
        else:
            # For non-OPTIONS requests, continue processing
            response = await call_next(request)

        # Add CORS headers to the response
        response.headers["Access-Control-Allow-Origin"] = "*"  # Replace with your specific origin(s)
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type"

        return response