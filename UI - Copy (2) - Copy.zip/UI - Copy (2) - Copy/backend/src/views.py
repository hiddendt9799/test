from fastapi import APIRouter
from src.schema import *
from config import settings

router = APIRouter(
    tags=["Vectorstore"],
    dependencies=[],
    responses={404: {"description": "Not found"}},
)

@router.post("/ask/", response_model=AnswerResponse)
async def get_answer(request: QuestionRequest):
    # Hardcoded answer and supporting content
    answer = "Hardcoded Response"
    supporting_content = [
        {
            "filename": "Wikipedia",
            "content": "This is a hardcoded response showing how the UI functions.",
            "url": "https://www.wikipedia.org"
        }
    ]
    thought_process = [
        ThoughtStep(
            title="Original User Query",
            description=request.question
        ),
        ThoughtStep(
            title="Generated Search Query",
            description=f"Hardcoded response based on query: {request.question}",
            props={"use_semantic_captions": False, "has_vector": False}
        ),
        ThoughtStep(
            title="Results",
            description=[{
                "id": "Wikipedia",
                "content": "This is a hardcoded response showing how the UI functions.",
                "sourcepage": "https://www.wikipedia.org"
            }]
        ),
        ThoughtStep(
            title="Prompt",
            description={
                "role": "system",
                "content": "Provide a simple response for testing UI functionality."
            }
        )
    ]

    # Returning the hardcoded answer and supporting content
    return AnswerResponse(
        answer=answer,
        supporting_content=supporting_content,
        thought_process=thought_process
    )
# from fastapi import APIRouter

# from config import settings
# from src.schema import *
# from src.utils.vector_db import VectorDatabase
# from src.utils.vector_db.pgvector import PostgresVector
# from src.utils.llm import LLM
# from src.utils.prompt import prompt


# vector_db = VectorDatabase()
# # Connects to faiss db by default
# # Below is a strategy pattern
# # The below code selects the pgvector
# vector_db._set_db(PostgresVector, config=settings.POSTGRES_DB_CONFIG)

# llm = LLM()
# chain = prompt | llm


# router = APIRouter(
#     tags=["Vectorstore"],
#     dependencies=[],
#     responses={404: {"description": "Not found"}},
# )


# @router.post("/ask/", response_model=AnswerResponse)
# async def get_answer(request: QuestionRequest):
#     query = request.question
#     search_results = vector_db.search(query, k=5, threshold=0.1)
#     supporting_content = []
#     if search_results:
#         context = '\n'.join(search_results["file_text"])
#         context = llm.model.truncate_tokens(context)
#         supporting_content = [
#             {"filename": file_name,"content":file_text, "url":url}
#             for file_name, file_text, url in zip(search_results["file_names"], search_results["file_text"], search_results["file_links"])
#         ]

#         answer = chain.invoke({
#         "question": query,
#         "context": context
#         })

#         thought_process =[
#             ThoughtStep(
#                 title="Original User Query",
#                 description=query
#             ),
#             ThoughtStep(
#                 title="Generated Search Query",
#                 description=f"{query}",
#                 props = {"use_semantic_captions": False,"has_vector": True}
#             ),
#             ThoughtStep(
#                 title= "Results",
#                 description=[{
#                     "id": file_name, "content": file_text,
#                     "sourcepage": file_link
#                     } for file_name, file_link, file_text in 
#                     zip(search_results["file_names"], search_results["file_links"], search_results["file_text"])]
#             ),
#             ThoughtStep(
#                 title="Prompt",
#                 description={
#                     "role": "system",
#                     "content": "Provide concise and relevant answer based on the employee handbook."
#                 }
#             )
#         ]
#     else:
#         answer = "No Matching result Found."

#     return AnswerResponse(answer=answer.content, 
#                           supporting_content=supporting_content,
#                           thought_process=thought_process)
