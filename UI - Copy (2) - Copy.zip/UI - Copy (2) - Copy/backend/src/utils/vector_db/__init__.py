from src.utils.base.vector_db import VectorDB
from src.utils.vector_db.faiss import FaissDB
from config import settings

class VectorDatabase:
    def __init__(self, db:VectorDB=FaissDB, config:dict=settings.FAISS_DB_CONFIG):
        self._db=db(config)
    
    def _set_db(self, db:VectorDB, config:dict):
        self._db = db(config)

    def search(self, query:str, threshold:float=None, k:int=None):
        return self._db.search(query=query, threshold=threshold, k=k)


