import requests
from src.utils.base.vector_db import VectorDB


class FaissDB(VectorDB):
    def __init__(self, config) -> None:
        self.url = config["url"]
    
    def search(self, query: str, threshold:float, k:int):
        data = {
        "prompt_input": query
        }
        
        response = requests.post(self.url, json=data, verify=False)
        result = response.json()
        
        return self.__filter_results(result, threshold=threshold, k=k)
    
    def __filter_results(self, result, threshold, k):
        similarity:list = result["file_similarity"]
        file_names:list = result["file_names"]
        file_links:list = result["file_links"]
        file_text:list = result["file_text"]
        num_items = len(similarity)
        similarity_index=[i for i in range(num_items)]
        if k:
            assert k>0
            similarity_index = self.__get_sorted_index(similarity)
            similarity_index = similarity_index[0:k] if k <= num_items else similarity_index
            similarity = [similarity[i] for i in similarity_index]
        if threshold:
            assert 0<=threshold<=1
            similarity_index = [i>=threshold for i in similarity]
            similarity_index = [index for index,val in enumerate(similarity_index) if val]
            similarity = [similarity[i] for i in similarity_index]
        return {
            "file_similarity":similarity,
            "file_names":[file_names[i] for i in similarity_index],
            "file_links":[file_links[i] for i in similarity_index],
            "file_text":[file_text[i] for i in similarity_index]
        }
    
    def __get_sorted_index(self, scores:list):
        scores_and_index = list(enumerate(scores))
        scores_and_index.sort(key=lambda x: x[1], reverse=True)
        return [i[0] for i in scores_and_index]




