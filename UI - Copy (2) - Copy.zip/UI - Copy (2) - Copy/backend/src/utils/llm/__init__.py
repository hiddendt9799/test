from langchain_core.runnables import Runnable
from src.utils.llm.azure_openai import AzureOpenAILLM
from src.utils.base.llm import LLM
from config import settings

class LLM(Runnable):
    def __init__(self, model:LLM=AzureOpenAILLM, config:dict=settings.AZURE_OPENAI_CONFIG):
        super().__init__()
        self.model = model(config=config)

    def _set_model(self, strategy:LLM, config:dict):
        self.model = strategy(config=config)

    def invoke(self, prompt, *args, **kwargs):
        return self.model.get_response(prompt)
    

"""
Default
llm = LLM()
llm.invoke("prompt")

This uses AzureOpenAI by default
The above pattern lets you swithch LLM in the midst of execution

If you need to use some other LLM, start by creating an LLM subclass

class SomeLLM(LLM):
    def get_response(self, prompt):
        "Some implementation for getting response"
        return response

some_llm_config = {"foo":"bar"}

To switch to some llm based on some user choice:

llm.set_model(SomeLLM, config=some_llm_config)
llm.invoke("prompt")

To switch back:

llm.set_model(AzureOpenAILLM, config=azure_openai_config)
llm.invoke("prompt")


This will come handy while integrating other open-source model deployments or
LLMs from other cloud providers


The LLM class is a runnable. To create a basic chain using langchain

chain = prompt | llm | parser
chain.invoke({"foo":"bar"})
"""
