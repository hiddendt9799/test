from langchain_openai import AzureChatOpenAI, AzureOpenAI
from src.utils.auth.azure import Auth
from src.utils.base.llm import LLM
import tiktoken

class AzureOpenAIBuilder:
    """
    Class for getting Azure OpenAI handlers from langchain, given the model deployment details
    """
    _auth = Auth()
    def get_llm(self, config:dict):

        model_name = config["model_name"]
        azure_deployment = config["azure_deployment"]
        api_version = config["api_version"]
        azure_endpoint = config["azure_endpoint"]
        temperature = config["temperature"]
        api_key = config["api_key"]
        assert 0 <= temperature <= 1
        if api_key:
            llm = AzureChatOpenAI(
                    model=model_name,
                    azure_deployment=azure_deployment,
                    azure_endpoint=azure_endpoint,
                    api_version=api_version,
                    temperature=temperature,
                    api_key=api_key
                )
        else:
            llm = AzureChatOpenAI(
                    model=model_name,
                    azure_deployment=azure_deployment,
                    azure_endpoint=azure_endpoint,
                    api_version=api_version,
                    temperature=temperature,
                    azure_ad_token_provider=self._auth.get_token
                )
        return llm

    


class AzureOpenAILLM(LLM):
    """
    An LLM that uses Azure OpenAI deployments and langchain
    """
    builder = AzureOpenAIBuilder()
    def __init__(self, config:dict):
        self.model = self.builder.get_llm(config=config)
    
    def get_response(self, prompt: str) -> str:
        return self.model.invoke(prompt)
    
    def truncate_tokens(self, prompt, ):
        enc = tiktoken.encoding_for_model(self.model.model_name)
        max_tokens = enc.max_token_value
        tokens = enc.encode(prompt)
        num_tokens = len(tokens)
        if num_tokens > max_tokens:
            tokens = tokens[:int(0.9*max_tokens)]
        return enc.decode(tokens=tokens)