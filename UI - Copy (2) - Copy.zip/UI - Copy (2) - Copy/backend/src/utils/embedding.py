from langchain_openai import AzureOpenAIEmbeddings
from src.utils.auth.azure import Auth
from config import settings

embedding_model = AzureOpenAIEmbeddings(**settings.AZURE_OPENAI_EMBEDDING_CONFIG, azure_ad_token_provider=Auth().get_token)