from enum import Enum

class ModelNames(Enum):
    gpt_35_turbo:str = "gpt-35-turbo"
    gpt_4:str = "gpt-4"
    gpt_4o:str = "gpt-4o"