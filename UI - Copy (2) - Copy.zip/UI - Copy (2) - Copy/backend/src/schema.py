from pydantic import BaseModel
from typing import Optional, List, Any, Dict
from src.constants import ModelNames


class ThoughtStep(BaseModel):
    title: str
    description: Optional[Any] = None
    Props: Optional[dict[str, Any]] = None

class QuestionRequest(BaseModel):
    question: str
    model: str = ModelNames.gpt_4o.value
    # conversation_id : str

class AnswerResponse(BaseModel):
    answer:str
    supporting_content: List[Dict[str, Any]]
    thought_process: List[ThoughtStep]

# Model for feedback submission
class Feedback(BaseModel):
    question_answer_id: str
    thumbs_up: int = 0  # Default to 0
    thumbs_down: int = 0  # Default to 0

class FeedbackSubmission(BaseModel):
    question_answer_id: str
    feedback: str  # Feedback text

# The below model is for directlt parsing LLM response
class GeneratedAnswer(BaseModel):
    answer: str