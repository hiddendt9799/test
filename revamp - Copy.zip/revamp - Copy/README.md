 
## Prerequisites
 
1. **Node Package Manager (npm)** - Required to install and manage frontend dependencies.
2. **Docker (Optional)** - For containerizing the project to create a stable development environment.
 
## Installation and Setup
 
### Step 1: Install npm
 
If npm is not already installed, download and install it [here](https://nodejs.org/).
 
### Step 2: Install Project Libraries
 
To install all dependencies for both frontend and backend:
 
- Frontend:
 ```bash
 npm install
 ```
 
- Backend:
 ```bash
 pip install -r requirements.txt
 ```
 
### Step 3: Run the Project
 
#### FOR LOCAL RUN
 
- **Running the Frontend**  
 Start the frontend by running:
 ```bash
 npm start
 ```
 
- **Running the Backend**  
 Open the backend app folder (`backend/app/app`) in your terminal and start the backend using:
 ```bash
 uvicorn main:app --reload
 ```
 If you encounter a certificate error (e.g., an OpenAI connection error), resolve it by setting the SSL certificate directory:
 ```bash
 export SSL_CERT_DIR=/usr/lib/ssl/certs
 ```
 
### API Endpoints
 
The frontend API configuration can be found in `api.service.ts`. Main API endpoints include:
 
1. **Question Answering API**: `http://localhost:8000/api/ask`
2. **Authentication**: `/api/auth/`
3. **User Information**: `/oauth2/userinfo`
4. **Feedback Endpoints**:
- Thumbs Up/Down: `http://localhost:8000/api/feedback/thumbs`
- Feedback Submit: `http://localhost:8000/api/feedback/submit`
 
#### FOR DOCKER RUN
 
To run the application using Docker:
 
1. Ensure Docker and its dependencies are installed.
2. Run the application:
  ```bash
  sudo docker-compose up --build
  ```
 
---
  
## Prerequisites
 
1. **Node Package Manager (npm)** - Required to install and manage frontend dependencies.
2. **Docker (Optional)** - For containerizing the project to create a stable development environment.
 
---
 
## Installation and Setup
 
### Step 1: Install npm
If npm is not already installed, download and install it [here](https://nodejs.org/).
 
---
 
### Step 2: Install Project Libraries
To install all dependencies for both frontend and backend:
 
- **Frontend**:
  ```bash
  npm install
  ```
 
- **Backend**:
  ```bash
  pip install -r requirements.txt
  ```
 
---
 
### Step 3: Run the Project
 
#### **FOR LOCAL RUN**
 
**Running the Frontend**
```bash
npm start
```
 
**Running the Backend**
1. Navigate to the backend app folder (`backend/app/app`) in your terminal.
2. Start the backend using:
   ```bash
   uvicorn main:app --reload
   ```
 
If you encounter a certificate error (e.g., OpenAI connection error), resolve it by setting the SSL certificate directory:
```bash
export SSL_CERT_DIR=/usr/lib/ssl/certs
```
 
---
 
#### **FOR DOCKER RUN**
 
1. Ensure Docker and its dependencies are installed.
2. Run the application:
   ```bash
   sudo docker-compose up --build
   ```
 
---
 
## API Endpoints
 
The frontend API configuration can be found in `api.service.ts`. Main API endpoints include:
 
1. **Question Answering API**:  
`http://localhost:8000/api/ask`
 
2. **Authentication**:  
   `/api/auth/`
 
3. **User Information**:  
   `/oauth2/userinfo`
 
4. **Feedback Endpoints**:
   - Thumbs Up/Down:  
`http://localhost:8000/api/feedback/thumbs`
   - Feedback Submit:  
`http://localhost:8000/api/feedback/submit`
 
---
 
## Setting Up `.npmrc` for Allianz Nexus Authentication
 
To configure your project to use Allianz's Nexus registry, follow these steps to set up the `.npmrc` file with the necessary credentials.
 
### Step-by-Step Guide
 
1. **Open Terminal**  
   Begin by opening a terminal window on your local development environment.
 
2. **Generate `.npmrc` in the HOME Directory**  
   Run the following command to set the Nexus registry as the default npm registry:
   ```bash
npm config set registry "https://nexus-frontend.frameworks.allianz.io/repository/npm-public/"
   ```
 
3. **Generate Nexus Authentication Token**  
   Use the command below to log in to the Nexus registry and generate an authentication token:
   ```bash
npm login --registry=https://nexus-frontend.frameworks.allianz.io/repository/npm-public/
   ```
   When prompted, provide the following details:
   - **Username**: Enter your staff ID.  
   - **Password**: Enter your toolchain password.  
   - **Email**: Enter your Allianz email ID.
 
4. **Copy `.npmrc` to Project Directory**  
   This process creates an `.npmrc` file in your home directory (`~/.npmrc`). Copy this file to your project's frontend folder:
   ```bash
   cp ~/.npmrc /path/to/brian-uwgt-app/frontend
   ```
 
5. **Build the Application**  
   Now that your `.npmrc` file is correctly configured in the project directory, you should be able to build the application without encountering registry-related issues.
 
**Notes**:
- Ensure that the `.npmrc` file with credentials is **not** checked into source control, as it contains sensitive information.
- This configuration is necessary to allow npm to access Allianz-specific packages from the Nexus registry.
 
---
 
## SSL Certificate Setup
 
If you encounter SSL certificate issues when running the backend (e.g., connection errors with external APIs), follow these steps to configure the SSL certificates:
 
1. **Copy SSL Certificates**  
   First, copy the required SSL certificates to the appropriate directory:
   ```bash
   sudo cp -r ./ca-certificates /usr/local/share/ca-certificates
   ```
 
2. **Update the Certificate Registry**  
   Next, update the certificate registry so the system recognizes the newly added certificates:
   ```bash
   sudo update-ca-certificates
   ```
 
3. **Verify SSL Certificate Directory**  
   Run the following command to check the SSL certificate directory:
   ```bash
   echo $SSL_CERT_DIR
   ```
 
4. **Set the SSL Certificate Directory**  
   Finally, set the SSL certificate directory as an environment variable:
   ```bash
   export SSL_CERT_DIR=/usr/lib/ssl/certs
   ```
 
These steps ensure that SSL certificates are correctly configured, allowing secure connections for the backend services.