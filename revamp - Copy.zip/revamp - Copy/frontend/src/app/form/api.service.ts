import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { HttpErrorResponse, HttpResponse } from "@angular/common/http";

import { Observable, throwError } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class ApiService {
  // API endpoints.
  apiUrl = "http://127.0.0.1:8000/api/ask/";
  // authUrl = "/api/auth/";  // Commented out: OAuth authentication URL
  userInfoUrl = "http://127.0.0.1:8000/oauth2/userinfo";  // Commented out: User info endpoint
  feedbackUrl = "http://127.0.0.1:8000/api/feedback/thumbs/"; // Endpoint for thumbs up/down
  feedbackSubmitUrl = "http://127.0.0.1:8000/api/feedback/submit/"; // Endpoint for feedback submission
  
  constructor(private http: HttpClient) {}

  private generateSessionId(): string {
    return Math.random().toString(36).substring(2, 15);
  }

  // to refetch the sess id everytime a request is made. to ensure sess id is in sync with local storage
  public getSessionId(): string {
    let sessionId = sessionStorage.getItem('session_id');
    if (!sessionId) {
      sessionId = this.generateSessionId();
      sessionStorage.setItem('session_id', sessionId);
    }
    return sessionId;
  }

  public sendQuestion(requestData: { question: string; session_id: string; }): Observable<{ answer: string; citations: string[] }> {
    return this.http.post<{ answer: string; citations: string[] }>(this.apiUrl, requestData);
  }

  // public getUserDetails() {  // Commented out: OAuth-related user info fetch
  //   return this.http.get<any>(this.userInfoUrl);
  // }

  // public doAuth() {  // Commented out: OAuth authentication method
  //   return this.http.get<any>(this.authUrl);
  // }

  public submitFeedback(questionAnswerId: string, thumbsUp: number, thumbsDown: number): Observable<any> {
    const payload = { question_answer_id: questionAnswerId, thumbs_up: thumbsUp, thumbs_down: thumbsDown };
    return this.http.post(this.feedbackUrl, payload);
  }

  public submitFeedbackText(questionAnswerId: string, feedback: string): Observable<any> {
    const payload = { question_answer_id: questionAnswerId, feedback };
    return this.http.post(this.feedbackSubmitUrl, payload);
  }

}

// import { Injectable } from "@angular/core";
// import { HttpClient } from "@angular/common/http";
// import { HttpErrorResponse, HttpResponse } from "@angular/common/http";

// import { Observable, throwError } from "rxjs";

// @Injectable({
//   providedIn: "root",
// })
// export class ApiService {
//   // API endpoints.
//   apiUrl = "/api/ask/";
//   authUrl = "/api/auth/";
//   userInfoUrl = "/oauth2/userinfo";
//   feedbackUrl = "/api/feedback/thumbs/"; // Endpoint for thumbs up/down
//   feedbackSubmitUrl = "/api/feedback/submit/"; // Endpoint for feedback submission
  
//   constructor(private http: HttpClient) {}

//   private generateSessionId(): string{
//     return Math.random().toString(36).substring(2,15);
//   }

//   // to refetch the sess id everytime a request is made. to ensure sess id is in sync with local storage
//   public getSessionId(): string {
//     let sessionId = sessionStorage.getItem('session_id');
//     if (!sessionId){
//       sessionId = this.generateSessionId();
//       sessionStorage.setItem('session_id',sessionId)
//     }
//     return sessionId;
//   }

//   public sendQuestion( requestData: { question: string; session_id: string; 
//   }): Observable<{answer: string; citations: string[] }> { return this.http.post<{ answer: string; citations: string[] }>(this.apiUrl, requestData); }
  
//   public getUserDetails() {
//     return this.http.get<any>(this.userInfoUrl);
//   }

//   public doAuth() {
//     return this.http.get<any>(this.authUrl);
//   }

//   public submitFeedback(questionAnswerId: string, thumbsUp: number, thumbsDown: number): Observable<any> {
//     const payload = { question_answer_id: questionAnswerId, thumbs_up: thumbsUp, thumbs_down: thumbsDown };
//     return this.http.post(this.feedbackUrl, payload);
//   }

//   public submitFeedbackText(questionAnswerId: string, feedback: string): Observable<any> {
//     const payload = { question_answer_id: questionAnswerId, feedback };
//     return this.http.post(this.feedbackSubmitUrl, payload);
//   }

// }
