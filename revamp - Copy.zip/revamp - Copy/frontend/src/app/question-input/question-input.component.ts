import { Component, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-question-input',
  templateUrl: './question-input.component.html',
  styleUrls: ['./question-input.component.css']
})
export class QuestionInputComponent {
  @Input() disableRequiredAccesscontrol = false;
  @Input() placeholder = 'Type your question here....';
  @Input() sendQuestionDisabled = false;
  @Output() questionChange = new EventEmitter<string>();
  @Output() sendQuestion = new EventEmitter<{ question: string, uploadedFileUrl: string | null }>();

  question:string='';

  selectedFile: File | null = null;
  uploadedFile: File | null = null;
  uploadedFileUrl: string | null = null;

  constructor(private http: HttpClient) {}

  onQuestionChange(event: any): void {
    const textarea=event.target;
    textarea.style.height='auto';
    textarea.style.height=`${textarea.scrollHeight}px`;
    this.question = event.target.value;
    this.questionChange.emit(this.question);
  }


  onEnterPress(event: KeyboardEvent): void {
    if (!this.sendQuestionDisabled && event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.send();
    }
  }

  send(): void {
    if (!this.sendQuestionDisabled && (this.question.trim() || this.uploadedFileUrl)){
      console.log('Sending question:', this.question, 'with file:', this.uploadedFileUrl);  // Debugging log
      this.sendQuestion.emit({ question: this.question, uploadedFileUrl: this.uploadedFileUrl });
      this.question = ''; // Clear the question
      this.removeUploadedFile(); // Clear the uploaded file after sending, if any
  
      // Reset the textarea height to default
      const textarea = document.querySelector('.questionInputTextArea') as HTMLElement;
      if (textarea) {
        (textarea as HTMLTextAreaElement).style.height = 'auto';  // Reset height to 'auto'
      }
    } else {
      console.log('Nothing to send');   // Debugging log for empty input
    }
  }

  setQuestion(value: string): void {
    this.question = value;
    this.questionChange.emit(this.question);
  }

  triggerFileUpload(): void {
    const fileInput = document.querySelector('.fileInput') as HTMLElement;
    fileInput.click();
  }

  handleFileInput(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      console.log('File selected:', file);

      const formData = new FormData();
      formData.append('file', this.selectedFile, this.selectedFile.name);

      const uploadUrl = 'http://localhost:8000/upload-pdf'; // Replace with actual backend URL

      this.http.post(uploadUrl, formData, { responseType: 'json' }).subscribe(
        (response: any) => {
          console.log('Upload successful!', response);
          this.uploadedFile = this.selectedFile;
          this.uploadedFileUrl = URL.createObjectURL(this.uploadedFile);

          this.selectedFile = null;
        },
        (error) => {
          console.error('Upload failed!', error);
        }
      );
    } else {
      console.log('No file selected.');
    }
  }

  removeUploadedFile(): void {
    this.uploadedFile = null;
    this.selectedFile = null;
    this.uploadedFileUrl = null;
  }
}