import { Component, Input, OnChanges, SimpleChanges,Output,EventEmitter, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { DomSanitizer, SafeResourceUrl, SafeHtml } from '@angular/platform-browser';

interface SupportingContent {
  filename: string;
  content: string;
  url: string;
}
 
interface ChatAppResponse {
  context?: {
    thoughts? : string[];
    data_points?: string[];
  };
}
 
@Component({
  selector: 'app-analysis-panel',
  templateUrl: './analysis-panel.component.html',
  styleUrls: ['./analysis-panel.component.css']
})
export class AnalysisPanelComponent implements OnChanges {
  @Input() answer!: ChatAppResponse;
  @Input() activeTab!: string;
  @Input() citationHeight!: string;
  @Input() activeCitation!: string;
  @Input() supportingContent: SupportingContent[] = [];
  @Input() thoughtProcess: any[] = [];
  @Output() closePanel: EventEmitter<void> = new EventEmitter<void>();
 
  citation: string = '';
  sanitizedCitationUrl: SafeResourceUrl | undefined;
  isResizing = false;
  sanitizedSupportingContent: SafeHtml[] = [];  // For holding sanitized content
 
  constructor(private sanitizer: DomSanitizer, private renderer: Renderer2) {}
 
  ngOnChanges(changes: SimpleChanges): void {
    console.log("changes detected:",changes)
 
   
    // if (changes['activeCitation'] && this.activeCitation){
    //   // const pdfURL = `assets/data/${this.activeCitation}&zoom=75`;
    //   const sharepointUrl = `https://allianzms.sharepoint.com/sites/gb0041-connect-az-uk-c-underwriting/`;
 
    //   console.log('PDF url',sharepointUrl)
    //   this.sanitizedCitationUrl = this.sanitizer.bypassSecurityTrustResourceUrl(sharepointUrl);
    //   console.log('sanitized:',this.sanitizedCitationUrl)
    // }
 
    if (changes['supportingContent'] && this.supportingContent) {
      console.log("loaded supporting content:", this.supportingContent);
      this.sanitizedSupportingContent = this.supportingContent.map(item =>
      this.sanitizer.bypassSecurityTrustHtml(item.content) // Sanitize each content item
      );
    }    
  }
 
  private stripAndSymbols(content:string):string{
    return content.replace(/&&/g,'');
  }
 
  closeAnalysisPanel(): void {
    this.closePanel.emit();
  }
 
}