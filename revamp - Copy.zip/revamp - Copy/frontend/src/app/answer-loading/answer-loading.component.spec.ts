import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnswerLoadingComponent } from './answer-loading.component';

describe('AnswerLoadingComponent', () => {
  let component: AnswerLoadingComponent;
  let fixture: ComponentFixture<AnswerLoadingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AnswerLoadingComponent]
    });
    fixture = TestBed.createComponent(AnswerLoadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
