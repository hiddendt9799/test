import { Component, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-clear-chat-button',
  templateUrl: './clear-chat-button.component.html',
  styleUrls: ['./clear-chat-button.component.css']
})
export class ClearChatButtonComponent {
  @Input() className?:string;
  @Input() disabled?: boolean;
  @Output() onclear = new EventEmitter<void>();
  @Input() clearChatDisabled:boolean=true;

  clearclick(): void {
    if(!this.clearChatDisabled){
      this.onclear.emit(); 
    } 
  }
}