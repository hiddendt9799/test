import { Component,Input } from '@angular/core';

@Component({
  selector: 'app-user-chat-message',
  templateUrl: './user-chat-message.component.html',
  styleUrls: ['./user-chat-message.component.css']
})
export class UserChatMessageComponent {
  @Input() message!:string;
}
