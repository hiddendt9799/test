from fastapi import status
from fastapi.responses import JSONResponse
import openai
from starlette.exceptions import HTTPException


class ExceptionHandler:
    """
    Class to define exception handler
    """

    @staticmethod
    async def handler(request, exc):
        """
        Handles exceptions and returns JSON response based on exception type
        :param request:
        :param exc:
        :return:
        """
        if isinstance(exc, HTTPException):
            return JSONResponse(
                content=exc.detail,
                status_code=exc.status_code
            )

        return JSONResponse(
            content={
                "message": "Something went wrong"
            },
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)