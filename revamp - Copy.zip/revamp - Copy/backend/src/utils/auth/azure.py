import os
from loguru import logger
from azure.identity import DefaultAzureCredential, EnvironmentCredential, ClientSecretCredential
from config import settings

class Auth:

    def __init__(self) -> None:
            credential = self.__setup_azure_credentials()
            assert credential, "No credentials provided"
            self.credential = credential

    def __setup_azure_credentials(self):
        tenant_id = settings.AZURE_TENANT_ID
        client_id = settings.AZURE_CLIENT_ID
        client_secret = settings.AZURE_CLIENT_SECRET

        if tenant_id and client_id and client_secret:
            # using service principal by service
            logger.info("Azure credentials provided by service principal")
            return ClientSecretCredential(tenant_id=tenant_id, client_id=client_id, client_secret=client_secret)
        else:
            # using developer token by local token
            logger.info("Azure credentials provided by interactive browser default credential")
            return DefaultAzureCredential()
    
    def get_token(self, url="https://cognitiveservices.azure.com/.default"):
        return self.credential.get_token(url).token 
                 