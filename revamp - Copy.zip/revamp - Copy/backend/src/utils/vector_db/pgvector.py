from langchain_postgres.vectorstores import PGVector
from psycopg2 import OperationalError
from src.utils.base.vector_db import VectorDB
from src.utils.auth.azure import Auth
from src.utils.embedding import embedding_model

class PostgresVector(VectorDB):
    def __init__(self, config:dict) -> None:
        self.pg_host = config["pg_host"]
        self.pg_user = config["pg_user"]
        self.pg_database = config["pg_database"]
        self.pg_password = Auth().get_token("https://ossrdbms-aad.database.windows.net/.default")
        self.pg_port = config["pg_port"]
        self.collection_name = config["collection_name"]
        self.connection_string = f"postgresql+psycopg://{self.pg_user}:{self.pg_password}@{self.pg_host}:{self.pg_port}/{self.pg_database}"
        self.vector_store = PGVector.from_existing_index(
                                connection=self.connection_string,
                                embedding=embedding_model,
                                collection_name=self.collection_name 
                            )
    def __refresh_connection_string(self):
        self.pg_password = Auth().get_token("https://ossrdbms-aad.database.windows.net/.default")
        self.connection_string = f"postgresql+psycopg://{self.pg_user}:{self.pg_password}@{self.pg_host}:{self.pg_port}/{self.pg_database}"
        self.vector_store = PGVector.from_existing_index(
                                connection=self.connection_string,
                                embedding=embedding_model,
                                collection_name=self.collection_name 
                            )

    def search(self, query: str, threshold:float, k:int):
        try:
            results = self.vector_store.similarity_search_with_score(query=query, k=k)
            return self.__filter_results(result=results, threshold=threshold)      
        except OperationalError:
            self.__refresh_connection_string()
            return self.search(query=query)

    def __filter_results(self, result, threshold):
        similarity = []
        file_names = []
        file_links = []
        file_text = []

        for chunk, score in result:
            metadata = chunk.metadata
            section_name = str(metadata['section_title'])
            file_name = metadata["source"].split("/")[-1]
            if metadata["subsubsection"] != None:
                if section_name == "\xa0":
                    section_name = metadata["page_title"]
                section_name += "  " + str(metadata["subsubsection"])
            if section_name == "\xa0":
                section_name = metadata["page_title"]
            source_append = str(section_name) + "  (" + file_name + ")"
            file_names.append(source_append)
            file_links.append(metadata["link"])
            file_text.append(metadata["untagged_text"])
            similarity.append(score)

        num_items = len(similarity)
        similarity_index=[i for i in range(num_items)]
        if threshold:
            assert 0<=threshold<=1
            similarity_index = [i>=threshold for i in similarity]
            similarity_index = [index for index, val in enumerate(similarity_index) if val]
            similarity = [similarity[i] for i in similarity_index]
        return {
            "file_similarity":similarity,
            "file_names":[file_names[i] for i in similarity_index],
            "file_links":[file_links[i] for i in similarity_index],
            "file_text":[file_text[i] for i in similarity_index]
        }




