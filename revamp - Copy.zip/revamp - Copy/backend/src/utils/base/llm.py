from abc import ABC, abstractmethod
from langchain_openai import ChatOpenAI

class LLM(ABC):
    """Base class for integrating LLMs
    """
    @abstractmethod
    def get_response(self, prompt:str) -> str:
        """Get response from llm

        Args:
            prompt (str): _description_

        Raises:
            NotImplemented: _description_

        Returns:
            str: _description_
        """
        raise NotImplemented
    
    @abstractmethod
    def truncate_tokens(self, prompt):
        """Limit tokens to maximum context window

        Returns:
            _type_: _description_
        """
        return NotImplemented
        
