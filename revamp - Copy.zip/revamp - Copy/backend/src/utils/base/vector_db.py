from abc import ABC, abstractmethod

class VectorDB(ABC):

    @abstractmethod
    def search(self, query:str, *args, **kwargs):
        raise NotImplemented
    
    def insert(self, documents:list, embeddings:list, *args, **kwargs):
        raise NotImplemented