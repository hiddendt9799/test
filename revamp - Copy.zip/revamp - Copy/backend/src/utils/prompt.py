from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser

from src.schema import GeneratedAnswer

parser = JsonOutputParser(pydantic_object=GeneratedAnswer)


GENERATION_PROMPT_TEMPLATE = """
You are a helpful assistant for Allianz underwriters.
Your goal is to generate responses for the users question based on the information given below.
Context: {context}
Question:{question}  

Instructions:
1. Answer the questions only based on the given context.
2. The context may include multiple sources, use them and them only to answer the questions.
3. If the answer is not clear from the sources do not answer. Say that you dont't know.
4. If you dont't know the answer just say you don't know
5. Never try to make up an answer if it can't be found in the context
6. If you can find the answer try to add as much detail from the context. Make sure the response is proportional to the context.

**IMPORTANT**
1. The generated response must be in markdown format for readability.     
2. Return only the relevant answer
"""

prompt = PromptTemplate(template=GENERATION_PROMPT_TEMPLATE,
                        input_variables=["context", "question"],
                        output_parser=parser)
